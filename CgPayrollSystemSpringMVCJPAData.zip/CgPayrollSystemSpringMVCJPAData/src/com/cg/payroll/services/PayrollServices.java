package com.cg.payroll.services;

import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollServices {
	
	double calculateNetSalary(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;
	
	Associate getAssociateDetails(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;
	
	ArrayList<Associate> getAllAssociateDetails()throws PayrollServicesDownException;

	ArrayList<Associate> findFewAssociate(double yearlyInvestmentUnder8oC);

	Associate acceptAssociateDetails(Associate associate)throws PayrollServicesDownException;
	
	
}
