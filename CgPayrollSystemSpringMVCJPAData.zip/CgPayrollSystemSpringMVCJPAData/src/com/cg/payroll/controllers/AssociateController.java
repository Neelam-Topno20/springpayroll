package com.cg.payroll.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class AssociateController {

	@Autowired
	private PayrollServices payrollServices;
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult result) throws PayrollServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		
		associate=payrollServices.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage", "associate", associate);
	}
	@RequestMapping("/signInAssociate")
	public ModelAndView signInAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult result) throws PayrollServicesDownException, AssociateDetailNotFoundException {
		associate=payrollServices.getAssociateDetails(associate.getAssociateID());
		double netSalary=payrollServices.calculateNetSalary(associate.getAssociateID());
		associate.getSalary().setNetSalary(netSalary);
		return new ModelAndView("signInSuccessPage", "associate", associate);
	}
	@RequestMapping("/viewAllAssociates")
	public ModelAndView signInAssociateAction(@Valid@ModelAttribute ArrayList<Associate> associateList,BindingResult result) throws PayrollServicesDownException, AssociateDetailNotFoundException {
		associateList=payrollServices.getAllAssociateDetails();
		return new ModelAndView("viewAllAssociatesPage", "associateList", associateList);
	}
	/*@RequestMapping("/calculateNetSalaryAssociate")
	public ModelAndView calculateNetSalaryAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult result,@RequestParam("associateID") int associateId) throws PayrollServicesDownException, AssociateDetailNotFoundException {
		associate=payrollServices.getAssociateDetails(associateId);
		
		return new ModelAndView("signInSuccessPage", "associate", associate);
	}*/
}
